# Hemant Repair Shop Manager

Cloud-connected Android repair shop manager with Admin and Staff access.

- Firebase Authentication and Firestore cloud sync
- Admin email/password and Staff mobile/password login
- Live Pending, Repaired and Delivered dashboard
- Cloud repair jobs and status updates
- Admin-only staff account creation
