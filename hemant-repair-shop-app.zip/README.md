# Hemant Repair Shop Billing

Simple Android billing app for a mobile repair shop. It creates non-GST bills, stores them locally, tracks payment status, and can share a bill as PDF.

## Current build

- Shop: Hemant Repair Shop
- Invoice type: non-GST
- Local SQLite storage
- Customer, mobile number, device, repair details, amount and payment status
- PDF bill sharing

Cloud sync will be added after a Firebase project and configuration are supplied.

## Build

Run `gradle assembleDebug`. GitHub Actions also builds a downloadable debug APK after every push to `main`.
